/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 hedwig hedwig.png 
 * Time-stamp: Sunday 11/18/2018, 22:46:08
 * 
 * Image Information
 * -----------------
 * hedwig.png 56@80
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef HEDWIG_H
#define HEDWIG_H

extern const unsigned short hedwig[4480];
#define HEDWIG_SIZE 8960
#define HEDWIG_LENGTH 4480
#define HEDWIG_WIDTH 56
#define HEDWIG_HEIGHT 80

#endif

