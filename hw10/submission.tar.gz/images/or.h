/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 or or.png 
 * Time-stamp: Tuesday 11/20/2018, 14:11:26
 * 
 * Image Information
 * -----------------
 * or.png 40@40
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef OR_H
#define OR_H

extern const unsigned short or[1600];
#define OR_SIZE 3200
#define OR_LENGTH 1600
#define OR_WIDTH 40
#define OR_HEIGHT 40

#endif

