/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 begin0 begin0.png 
 * Time-stamp: Monday 11/19/2018, 14:34:36
 * 
 * Image Information
 * -----------------
 * begin0.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef BEGIN0_H
#define BEGIN0_H

extern const unsigned short begin0[38400];
#define BEGIN0_SIZE 76800
#define BEGIN0_LENGTH 38400
#define BEGIN0_WIDTH 240
#define BEGIN0_HEIGHT 160

#endif

