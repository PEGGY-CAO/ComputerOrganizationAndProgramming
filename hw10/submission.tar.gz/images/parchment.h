/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 parchment parchment.png 
 * Time-stamp: Monday 11/19/2018, 14:35:27
 * 
 * Image Information
 * -----------------
 * parchment.png 150@150
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef PARCHMENT_H
#define PARCHMENT_H

extern const unsigned short parchment[22500];
#define PARCHMENT_SIZE 45000
#define PARCHMENT_LENGTH 22500
#define PARCHMENT_WIDTH 150
#define PARCHMENT_HEIGHT 150

#endif

