/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 down down.png 
 * Time-stamp: Tuesday 11/20/2018, 14:11:14
 * 
 * Image Information
 * -----------------
 * down.png 40@40
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef DOWN_H
#define DOWN_H

extern const unsigned short down[1600];
#define DOWN_SIZE 3200
#define DOWN_LENGTH 1600
#define DOWN_WIDTH 40
#define DOWN_HEIGHT 40

#endif

