/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 not not.png 
 * Time-stamp: Tuesday 11/20/2018, 14:11:37
 * 
 * Image Information
 * -----------------
 * not.png 40@40
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef NOT_H
#define NOT_H

extern const unsigned short not[1600];
#define NOT_SIZE 3200
#define NOT_LENGTH 1600
#define NOT_WIDTH 40
#define NOT_HEIGHT 40

#endif

