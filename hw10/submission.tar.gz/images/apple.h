/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=15x15 apple apple.png 
 * Time-stamp: Monday 11/19/2018, 11:59:20
 * 
 * Image Information
 * -----------------
 * apple.png 15@15
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef APPLE_H
#define APPLE_H

extern const unsigned short apple[225];
#define APPLE_SIZE 450
#define APPLE_LENGTH 225
#define APPLE_WIDTH 15
#define APPLE_HEIGHT 15

#endif

