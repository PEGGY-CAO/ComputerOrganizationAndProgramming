/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 and and.png 
 * Time-stamp: Sunday 11/18/2018, 22:44:36
 * 
 * Image Information
 * -----------------
 * and.png 40@40
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef AND_H
#define AND_H

extern const unsigned short and[1600];
#define AND_SIZE 3200
#define AND_LENGTH 1600
#define AND_WIDTH 40
#define AND_HEIGHT 40

#endif

