This is a GBA game designed by Peggy Cao.
It's written in C, with GBA emulator.
It's Harry Potter theme. When it runs, the beginning scene shows. Then press[ENTER] to go to the second scene. Each scene will have promts for the user. In the second scene, you will need to feed an owl in order to move to the third scene. It is pretty intuitive that you use arrow key to move the apple to feed the owl. In the third scene, you have to press arrows according to the gates' direction in the window. Those gates are designed using logic gates with all due respect to CS 2110 from Georgia Tech. If you let the gates falling down the window, you'll lose. If you press the right arrow for 10 rounds, you'll win.

Thanks for all TA's help and hardworking.